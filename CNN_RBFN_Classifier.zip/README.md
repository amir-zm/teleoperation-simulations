# CNN-RBFN Image Classifier

This project investigates the hybridization of Convolutional Neural Networks (CNN) and Radial Basis Function Networks (RBFN) for image classification.

## Description

The final dense layer of a CNN trained on MNIST, Fashion-MNIST, and CIFAR-10 datasets is replaced by an RBF layer. This hybrid model:
- Uses CNN for feature extraction.
- Applies K-means to determine RBF centers.
- Uses Recursive Least Squares (RLS) to learn output layer weights.

## Features

- CNN-RBFN architecture
- K-means clustering for center selection
- RLS optimization for weight learning
- 10-fold cross-validation
- Visualizations of loss/accuracy

## Structure

- `models/cnn_model.py`: CNN model definition
- `rbfn/rbfn_layer.py`: RBFN logic and training
- `train.py`: Entry point to train and test the model
- `utils/metrics.py`: Metrics and utilities
- `plots/`: Saved training curves and evaluation results

## How to Run

1. Install dependencies:
```bash
pip install -r requirements.txt
```

2. Run training:
```bash
python train.py
```

## Author

Amir Zakerimanesh
